
import pandas as pd
import matplotlib.pyplot as plt

dataframe = pd.read_csv('./results_simulation.csv')

fig, axs = plt.subplots(2, 1, figsize=(10, 15), sharex=False)
fig.suptitle("Battery simulation Results")

minLimit = 0
maxLimit = 1000
t = dataframe["time"][minLimit:maxLimit]

axs[0].plot(t, dataframe["battery.soc"][minLimit:maxLimit])
axs[0].set_ylabel("")
axs[0].set_title("SoC output")
axs[0].legend(["battery.soc"])
axs[0].grid()

axs[1].plot(t, dataframe["battery.soh"][minLimit:maxLimit])
axs[1].plot(t, dataframe["linearmodel.SOH_phy"][minLimit:maxLimit])
axs[1].set_ylabel("")
axs[1].set_title("SoH outputs")
axs[1].legend(["battery.soh", "linearmodel.SOH_phy"])
axs[1].grid()

plt.show()