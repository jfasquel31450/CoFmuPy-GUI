
import pandas as pd
import matplotlib.pyplot as plt

dataframe = pd.read_csv('./results_simulation.csv')

fig, axs = plt.subplots(2, 1, figsize=(10, 15))
fig.suptitle("Battery simulation Results")

minLimit = 0
maxLimit = 1000
t = dataframe["time"][minLimit:maxLimit]

array_p = []
charge = []

for i in range(299):
    charge.append(0)
charge.append(1)
for i in range(700):
    charge.append(0)

for i in range(100):
    array_p.append(0)
for i in range(400):
    array_p.append(10000.0)
for i in range(100):
    array_p.append(0)
for i in range(200):
    array_p.append(500.0)
for i in range(200):
    array_p.append(20000.0)

dataframe["P"] = array_p

axs[1].plot(t, dataframe["battery.soc"][minLimit:maxLimit])
axs[1].plot(t, charge[minLimit:maxLimit])
axs[1].set_ylabel("")
axs[1].set_ylim(0.7, 1.01)
axs[1].set_title("SoC output")
axs[1].legend(["battery.soc", "charge"])
axs[1].grid()

axs[0].plot(t, array_p[minLimit:maxLimit])
axs[0].set_ylabel("")
axs[0].set_title("Expected Power")
axs[0].legend(["P"])
axs[0].grid()

plt.show()
