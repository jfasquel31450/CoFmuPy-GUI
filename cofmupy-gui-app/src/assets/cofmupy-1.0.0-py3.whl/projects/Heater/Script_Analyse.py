
import pandas as pd
import matplotlib.pyplot as plt

dataframe = pd.read_csv('./results_simulation.csv')

fig, axs = plt.subplots(1, 1, figsize=(10, 15))
fig.suptitle("Heater simulation Results")

t = dataframe["time"]

axs.plot(t, dataframe["Heater.T_out"])
axs.plot(t, dataframe["Programmer.T_out"])
axs.set_ylabel("")
axs.legend(["Heater", "Programmer"])
axs.grid()

plt.show()
